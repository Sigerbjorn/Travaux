#!/bin/bash

i= 0
while true
do
	i=`expr $i + 1`
	echo "Valeur: $i"
	sleep 2
done
